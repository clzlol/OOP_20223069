import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class BufferReading {
    public static void main(String[] args) {
        // try{
        //     String str = "\n";
        //     String add = "";
        //     while(true){
        //         BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        //         add = in.readLine();
        //         if(add.equals("quit"))
        //             break;
                
        //         str += add + "\n";
        //     }
        //     System.out.println(str);

        // }catch(IOException e){
        //     System.out.println(e);
        // }
        try{
            String str = "";
            BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
            str = in.readLine();
            StringTokenizer k = new StringTokenizer(str);
            System.out.println("There are " + Integer.valueOf(k.countTokens()) + " words in this line");
            while(k.hasMoreTokens()){
                System.out.println(k.nextToken());
            }
        }catch(IOException e){
            ;
        }
        
    }
}
