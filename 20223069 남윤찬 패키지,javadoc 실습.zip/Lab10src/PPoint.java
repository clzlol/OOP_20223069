package kr.ac.kookmin.cs;

/**
 * PPoint class
 */
public class PPoint {
    int xA;
    int yA;
    public PPoint(int x, int y) {
        xA = x;
        yA = y;
    };
    /**
     * return member variable xA
     * @return xA
     */
    public int getX() {
        return xA;
    }
    /**
     * return member variable yA
     * @return yA
     */
    public int getY() {
        return yA;
    }
}
